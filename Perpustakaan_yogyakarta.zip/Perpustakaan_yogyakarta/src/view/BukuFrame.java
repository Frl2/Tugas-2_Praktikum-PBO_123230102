/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;
import controller.BukuController;
import model.Buku;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;
import java.util.List;
/**
 *
 * @author Farrel
 */
public class BukuFrame extends JFrame {
    private JTextField tfJudul, tfGenre, tfPenulis, tfPenerbit, tfLokasi, tfStok, tfSearch;
    private JComboBox<String> cbKategori;
    private JTable table;
    private DefaultTableModel tableModel;
    private BukuController controller = new BukuController();
    private int selectedId = -1;

    public BukuFrame() {
        setTitle("Data Buku Perpustakaan");
        setSize(900, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Panel Form Input
        JPanel formPanel = new JPanel(new GridLayout(7, 2, 5, 5));
        formPanel.setBorder(BorderFactory.createTitledBorder("Perpustakaan Yogyakarta"));

        tfJudul = new JTextField();
        tfGenre = new JTextField();
        tfPenulis = new JTextField();
        tfPenerbit = new JTextField();
        tfLokasi = new JTextField();
        tfStok = new JTextField();

        formPanel.add(new JLabel("Judul:"));
        formPanel.add(tfJudul);
        formPanel.add(new JLabel("Genre:"));
        formPanel.add(tfGenre);
        formPanel.add(new JLabel("Penulis:"));
        formPanel.add(tfPenulis);
        formPanel.add(new JLabel("Penerbit:"));
        formPanel.add(tfPenerbit);
        formPanel.add(new JLabel("Lokasi:"));
        formPanel.add(tfLokasi);
        formPanel.add(new JLabel("Stok:"));
        formPanel.add(tfStok);

        // Panel Tombol
        JPanel buttonPanel = new JPanel();
        JButton btnTambah = new JButton("Tambah");
        JButton btnUbah = new JButton("Ubah");
        JButton btnHapus = new JButton("Hapus");
        JButton btnTampil = new JButton("Tampilkan Semua");

        buttonPanel.add(btnTambah);
        buttonPanel.add(btnUbah);
        buttonPanel.add(btnHapus);
        buttonPanel.add(btnTampil);

        // Panel Tabel
        tableModel = new DefaultTableModel(new String[]{"ID", "Judul", "Genre", "Penulis", "Penerbit", "Lokasi", "Stok"}, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        // Panel Search
        JPanel searchPanel = new JPanel();
        cbKategori = new JComboBox<>(new String[]{"judul", "genre", "penulis", "penerbit"});
        tfSearch = new JTextField(20);
        JButton btnCari = new JButton("Cari");

        searchPanel.add(new JLabel("Cari berdasarkan:"));
        searchPanel.add(cbKategori);
        searchPanel.add(tfSearch);
        searchPanel.add(btnCari);

        add(formPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.CENTER);
        add(scrollPane, BorderLayout.SOUTH);
        add(searchPanel, BorderLayout.PAGE_END);

        // Events
        btnTambah.addActionListener(e -> tambahBuku());
        btnUbah.addActionListener(e -> ubahBuku());
        btnHapus.addActionListener(e -> hapusBuku());
        btnTampil.addActionListener(e -> tampilkanSemua());
        btnCari.addActionListener(e -> cariBuku());

        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int row = table.getSelectedRow();
                selectedId = Integer.parseInt(table.getValueAt(row, 0).toString());
                tfJudul.setText(table.getValueAt(row, 1).toString());
                tfGenre.setText(table.getValueAt(row, 2).toString());
                tfPenulis.setText(table.getValueAt(row, 3).toString());
                tfPenerbit.setText(table.getValueAt(row, 4).toString());
                tfLokasi.setText(table.getValueAt(row, 5).toString());
                tfStok.setText(table.getValueAt(row, 6).toString());
            }
        });

        setVisible(true);
        tampilkanSemua(); // tampilkan data saat pertama buka
    }

    private void tambahBuku() {
        try {
            Buku buku = getBukuFromForm();
            controller.tambahBuku(buku);
            JOptionPane.showMessageDialog(this, "Data berhasil ditambahkan!");
            tampilkanSemua();
            clearForm();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void ubahBuku() {
        if (selectedId == -1) {
            JOptionPane.showMessageDialog(this, "Pilih data yang akan diubah!");
            return;
        }

        try {
            Buku buku = getBukuFromForm();
            buku.setIdBuku(selectedId);
            controller.ubahBuku(buku);
            JOptionPane.showMessageDialog(this, "Data berhasil diubah!");
            tampilkanSemua();
            clearForm();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void hapusBuku() {
        if (selectedId == -1) {
            JOptionPane.showMessageDialog(this, "Pilih data yang akan dihapus!");
            return;
        }

        try {
            controller.hapusBuku(selectedId);
            JOptionPane.showMessageDialog(this, "Data berhasil dihapus!");
            tampilkanSemua();
            clearForm();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void tampilkanSemua() {
        try {
            List<Buku> list = controller.getAllBuku();
            tableModel.setRowCount(0);
            for (Buku b : list) {
                Object[] row = {b.getIdBuku(), b.getJudul(), b.getGenre(), b.getPenulis(), b.getPenerbit(), b.getLokasi(), b.getStok()};
                tableModel.addRow(row);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error saat menampilkan data: " + ex.getMessage());
        }
    }

    private void cariBuku() {
        try {
            String kategori = cbKategori.getSelectedItem().toString();
            String keyword = tfSearch.getText();
            List<Buku> list = controller.searchBuku(kategori, keyword);
            tableModel.setRowCount(0);
            for (Buku b : list) {
                Object[] row = {b.getIdBuku(), b.getJudul(), b.getGenre(), b.getPenulis(), b.getPenerbit(), b.getLokasi(), b.getStok()};
                tableModel.addRow(row);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error saat mencari data: " + ex.getMessage());
        }
    }

    private Buku getBukuFromForm() {
        Buku buku = new Buku();
        buku.setJudul(tfJudul.getText());
        buku.setGenre(tfGenre.getText());
        buku.setPenulis(tfPenulis.getText());
        buku.setPenerbit(tfPenerbit.getText());
        buku.setLokasi(tfLokasi.getText());
        buku.setStok(Integer.parseInt(tfStok.getText()));
        return buku;
    }

    private void clearForm() {
        tfJudul.setText("");
        tfGenre.setText("");
        tfPenulis.setText("");
        tfPenerbit.setText("");
        tfLokasi.setText("");
        tfStok.setText("");
        tfSearch.setText("");
        selectedId = -1;
    }
}
