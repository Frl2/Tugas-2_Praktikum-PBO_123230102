/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;
import database.Koneksi;
import model.Buku;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Farrel
 */
public class BukuController {
    public void tambahBuku(Buku buku) throws SQLException {
        String sql = "INSERT INTO buku (judul, genre, penulis, penerbit, lokasi, stok) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = Koneksi.getConnection().prepareStatement(sql)) {
            ps.setString(1, buku.getJudul());
            ps.setString(2, buku.getGenre());
            ps.setString(3, buku.getPenulis());
            ps.setString(4, buku.getPenerbit());
            ps.setString(5, buku.getLokasi());
            ps.setInt(6, buku.getStok());
            ps.executeUpdate();
        }
    }

    public void ubahBuku(Buku buku) throws SQLException {
        String sql = "UPDATE buku SET judul=?, genre=?, penulis=?, penerbit=?, lokasi=?, stok=? WHERE id_buku=?";
        try (PreparedStatement ps = Koneksi.getConnection().prepareStatement(sql)) {
            ps.setString(1, buku.getJudul());
            ps.setString(2, buku.getGenre());
            ps.setString(3, buku.getPenulis());
            ps.setString(4, buku.getPenerbit());
            ps.setString(5, buku.getLokasi());
            ps.setInt(6, buku.getStok());
            ps.setInt(7, buku.getIdBuku());
            ps.executeUpdate();
        }
    }

    public void hapusBuku(int idBuku) throws SQLException {
        String sql = "DELETE FROM buku WHERE id_buku=?";
        try (PreparedStatement ps = Koneksi.getConnection().prepareStatement(sql)) {
            ps.setInt(1, idBuku);
            ps.executeUpdate();
        }
    }

    public List<Buku> getAllBuku() throws SQLException {
        List<Buku> list = new ArrayList<>();
        String sql = "SELECT * FROM buku";
        try (Statement st = Koneksi.getConnection().createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                Buku buku = new Buku();
                buku.setIdBuku(rs.getInt("id_buku"));
                buku.setJudul(rs.getString("judul"));
                buku.setGenre(rs.getString("genre"));
                buku.setPenulis(rs.getString("penulis"));
                buku.setPenerbit(rs.getString("penerbit"));
                buku.setLokasi(rs.getString("lokasi"));
                buku.setStok(rs.getInt("stok"));
                list.add(buku);
            }
        }
        return list;
    }

    public List<Buku> searchBuku(String kategori, String keyword) throws SQLException {
        List<Buku> list = new ArrayList<>();
        String sql = "SELECT * FROM buku WHERE " + kategori + " LIKE ?";
        try (PreparedStatement ps = Koneksi.getConnection().prepareStatement(sql)) {
            ps.setString(1, "%" + keyword + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Buku buku = new Buku();
                buku.setIdBuku(rs.getInt("id_buku"));
                buku.setJudul(rs.getString("judul"));
                buku.setGenre(rs.getString("genre"));
                buku.setPenulis(rs.getString("penulis"));
                buku.setPenerbit(rs.getString("penerbit"));
                buku.setLokasi(rs.getString("lokasi"));
                buku.setStok(rs.getInt("stok"));
                list.add(buku);
            }
        }
        return list;
        
        
    }
}
